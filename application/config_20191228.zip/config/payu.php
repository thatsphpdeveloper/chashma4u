<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    /**
     * Payment Mode
     **/
    $config['testmode']   = 'on';
    /**
     * Private Live Kay
     **/
    $config['LIVE_MERCHANT_KEY']    = 'sk_live_qSCSDqazcTpxRnCvntRTYonZ';
    $config['LIVE_SALT']    = 'sk_live_qSCSDqazcTpxRnCvntRTYonZ';

    $config['TEST_MERCHANT_KEY']    = 'gtKFFx';
    $config['TEST_SALT']    = 'eCwWELxi';

    $config['LIVE_URL']    = 'https://secure.payu.in/_payment';
    $config['TEST_URL']    = 'https://test.payu.in/_payment';


    /**
      * current merchant key
    **/
    $config['current_merchant_key'] = ($config['testmode'] == 'on') ? $config['TEST_MERCHANT_KEY'] : $config['LIVE_MERCHANT_KEY'];

    /**
      * current salt
    **/
    $config['current_salt'] = ($config['testmode'] == 'on') ? $config['TEST_SALT'] : $config['LIVE_SALT'];

    /**
      * current salt
    **/
    $config['current_url'] = ($config['testmode'] == 'on') ? $config['TEST_URL'] : $config['LIVE_URL'];
