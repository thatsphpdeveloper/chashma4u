<!-- <div class="lens-wrap"> -->
    <!-- <div data-id="lens-1" data-name="Classic" class="lens-inner">
    <label for="lens-1" class="radio-wrap">
        <input type="radio" id="lens-1" name="lens-option" value="1">
        <span></span>
    </label>
    <div class="detail-wrap">
        <div class="text">
            <span>Classic</span>
            <span>Scratch-resistant, anti-reflective lenses that block 100% of UV rays.</span>
        </div>
        <div class="price">
            <span class="us-pirce">
                <span>12.00</span>
            </span>
        </div>
    </div>
  </div>
  <div data-id="lens-2" data-name="Classic" class="lens-inner">
    <label for="lens-2" class="radio-wrap">
        <input type="radio" id="lens-2" name="lens-option" value="2">
        <span></span>
    </label>
    <div class="detail-wrap">
        <div class="text">
            <span>Blue-light-filtering</span>
            <span>Scratch-resistant, anti-reflective lenses that block 100% of UV rays; they also filter more blue light
                from digital screens and the sun than our classic lenses.
            </span>
        </div>
        <div class="price">
            <span class="us-pirce">
                <span>12.00</span>
            </span>
        </div>
    </div>
  </div>
  <div data-id="lens-3" data-name="Classic" class="lens-inner">
    <label for="lens-3" class="radio-wrap">
        <input type="radio" id="lens-3" name="lens-option" value="3">
        <span></span>
    </label>
    <div class="detail-wrap">
       <div class="text">
        <span>Light-responsive - Gray</span>
        <span>Scratch-resistant, anti-reflective lenses that block 100% of UV rays, transition from clear to a darker
            tint when you're outside, and filter more blue light than our classic lenses.</span>
        </div>
        <div class="price">
            <span class="us-pirce">
                <span> 12.00</span>
            </span>
        </div>
    </div>
  </div>
  <div data-id="lens-4" data-name="Classic" class="lens-inner">
    <label for="lens-4" class="radio-wrap">
        <input type="radio" id="lens-4" name="lens-option" value="4">
        <span></span>
    </label>
    <div class="detail-wrap">
       <div class="text">
        <span>Polarized Sunglasses - Gray</span>
        <span>Reduce glare for clearer vision and increase visual comfort.</span>
       </div>
        <div class="price">
            <span class="us-pirce">
                <span> 12.00</span>
            </span>
        </div>
    </div>
  </div>-->
 <?php echo$zeroPowerLenses?>
<!-- </div>  -->