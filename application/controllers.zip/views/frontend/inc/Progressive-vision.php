<!-- <div class="row mt-4" >
    <div class="col-lg-6" >
        <div class="custom-files-choses">
            <label> Upload your Prescription
            <input type="file" name="prescriptionImg">
            </label> 
        </div>
    </div>
    <div class="col-lg-6" >
        <div class="custom-files-choses">
            <label> Enter your Prescription
            <input type="checkbox" name="prescriptionEnter">
            </label> 
        </div>
    </div>
    
</div>

<div class="table-wrap table-responsive" style="display: block;"> -->
    <!-- prescription -->
    <!-- <table class="table-inner w-100">
        <thead>
            <tr>
                <th></th>
                <th><span>SPHERE (SPH)</span></th>
                <th><span>cylinder (CYL)</span></th>
                <th><span>AXIS</span></th>
                <th><span>ADD</span></th>
            </tr>
        </thead>
        <tbody class="add-hide" id="prescription-table">
            <tr>
                <td>Right Eye</td>
                <td>
                   <input type="text" class="form-control" name="rsph" placeholder="SPH"> 
                </td>
                <td>
                    <input type="text" class="form-control" name="rcyl" placeholder="CYL">
                </td>
                <td>
                   <input type="text" class="form-control" name="raxis" placeholder="AXIS">
                </td>
                <td>
                    <input type="text" class="form-control" name="radd" placeholder="Add"> 
                </td>
            </tr>
            left   -->
            <!-- <tr>
                <td>Left Eye</td>
                <td>
                    <input type="text" class="form-control" name="lsph" placeholder="SPH"> 
                </td>
                <td>
                    <input type="text" class="form-control" name="lcyl" placeholder="CYL"> 
                </td>
                <td>
                  <input type="text" class="form-control" name="laxis" placeholder="AXIS">
                </td>
                <td>
                    <input type="text" class="form-control" name="ladd" placeholder="Add">
                </td>
            </tr>
            <tr>
                <td>Additional Information</td>
                <td colspapn="3" class="w-100 ">
                    <textarea name="additionalInfo" class="form-control w-100" id="" cols="20"  ></textarea>
                </td>
               
            </tr>
        </tbody>
    </table> --> 
    <!-- prescription -->

<!-- </div> -->


