<?php $this->load->viewF('inc/header.php'); ?>
		<!--============= Paypal section Section ================-->
		<div class="grey-background">
			<div class="cart-section">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="starter-template">
						        <h1>PayPal Payment</h1>
						        <p class="lead">Canceld order</p>
						    </div>

						    <div class="contact-form">

						        <div>
						            <h3 style="font-family: 'quicksandbold'; font-size:16px; color:#313131; padding-bottom:8px;">Dear Member</h3>
						            <span style="color:#D70000; font-size:16px; font-weight:bold;">We are sorry! Your last transaction was cancelled.</span>
						        </div>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--============= Paypal section Section ================-->


	</body>
</html>