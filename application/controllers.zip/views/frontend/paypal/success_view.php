<?php $this->load->viewF('inc/header.php'); ?>
		<!--============= Paypal section Section ================-->
		<div class="grey-background">
			<div class="cart-section">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="starter-template">
						        <h1>PayPal Payment</h1>
						        <p class="lead">Success</p>
						    </div>

						    <div class="contact-form">
						        <div>
						            <h2 style="font-family: 'quicksandbold'; font-size:16px; color:#313131; padding-bottom:8px;">Dear Member</h2>
						            <span style="color: #646464;">Your payment was successful, thank you for purchase.</span><br/>
						        </div>
						    </div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--============= Paypal section Section ================-->


	</body>
</html>