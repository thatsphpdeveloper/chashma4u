<script>
	var DASHURL		= '<?php echo DASHURL; ?>';
	var BASEURL		= '<?php echo BASEURL; ?>';
	var UPLOADPATH	= '<?php echo UPLOADPATH; ?>';
	var DASHSTATIC	= '<?php echo DASHSTATIC; ?>';
	var FRONTSTATIC	= '<?php echo FRONTSTATIC; ?>';
</script>