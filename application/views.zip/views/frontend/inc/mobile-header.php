<div class="mobilemenu js-push-mbmenu">
            <div class="mobilemenu-content">
                <div class="mobilemenu-close mobilemenu-toggle">CLOSE</div>
                <div class="mobilemenu-scroll">
                    <div class="mobilemenu-search"></div>
                    <div class="nav-wrapper show-menu">
                        <div class="nav-toggle"><span class="nav-back"><i class="icon-arrow-left"></i></span> <span class="nav-title"></span></div>
                        <ul class="nav nav-level-1">
                        <?php //echo $mobileMenuHtml?>
                            <li><a href="javascript:void(0)">EYEGLASSES </a><span class="arrow"></span>
                                <ul class="nav-level-2">
                                    <li><a href="<?php echo BASEURL; ?>/men-eyeglasses" title=""  class="icon_box men" >Mens EYEGLASSES</a></li>
                                    <li><a href="<?php echo BASEURL; ?>/women-eyeglasses" title="" class="icon_box women">Women EYEGLASSES</a></li>
                                    <li><a href="<?php echo BASEURL; ?>/kids-eyeglasses" title="" class="icon_box kid">Kids EYEGLASSES</a></li>
                                </ul>
                            </li>
                             <li><a href="javascript:void(0)">Sunglasses </a><span class="arrow"></span>
                                <ul class="nav-level-2">
                                   <li><a href="<?php echo BASEURL; ?>/men-sunglasses" title=""  class="icon_box men" >Mens Sunglasses</a></li>
                                    <li><a href="<?php echo BASEURL; ?>/women-sunglasses" title="" class="icon_box women">Women Sunglasses</a></li>
                                    <li><a href="<?php echo BASEURL; ?>/kids-sunglasses" title="" class="icon_box kid">Kids Sunglasses</a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo BASEURL; ?>/sports-sunglasses">SPORTS SUNGLASSES </a></li>
                            <li><a href="<?php echo BASEURL; ?>/reading-eyewear">READING EYEGLASSES </a></li>
                        </ul>
                    </div>
                    <div class="mobilemenu-bottom">
                        <div class="mobilemenu-settings"></div>
                    </div>
                </div>
            </div>
        </div>